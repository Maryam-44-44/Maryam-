<?php
// block_users.php

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session with secure settings
session_set_cookie_params([
    'lifetime' => 86400, // 1 day
    'path' => '/',
    'domain' => 'https://sec-email.site', // Replace with your actual domain
    'secure' => true, // Ensure HTTPS is used
    'httponly' => true, // Prevents JavaScript access
    'samesite' => 'Strict', // Prevents CSRF
]);
session_start();

// Include the database configuration file
require_once '../config.php'; // Adjust the path as needed

// Admin authentication check
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Initialize messages
$success_message = "";
$error_message = "";

// CSRF Protection: Generate CSRF token if not present
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_message = "Invalid CSRF token.";
    } else {
        if (isset($_POST['block_user'])) {
            $email_to_block = trim($_POST['email']);

            // Validate email address
            if (filter_var($email_to_block, FILTER_VALIDATE_EMAIL)) {
                // Update user's status to 'blocked'
                $stmt = $pdo->prepare("UPDATE users SET status = 'blocked', blocked_at = NOW() WHERE email = ?");
                if ($stmt->execute([$email_to_block])) {
                    if ($stmt->rowCount() > 0) {
                        $success_message = "User with email <strong>" . htmlspecialchars($email_to_block) . "</strong> has been blocked.";

                        // Log the action
                        $action = 'Blocked User';
                        $details = "Admin ID {$_SESSION['admin_id']} blocked user $email_to_block.";
                        $log_stmt = $pdo->prepare("INSERT INTO logs (admin_id, action, details) VALUES (?, ?, ?)");
                        $log_stmt->execute([$_SESSION['admin_id'], $action, $details]);
                    } else {
                        $error_message = "Email address not found.";
                    }
                } else {
                    $error_message = "Failed to block user.";
                }
            } else {
                $error_message = "Invalid email address format.";
            }
        } elseif (isset($_POST['unblock_user'])) {
            $email_to_unblock = trim($_POST['email']);

            // Validate email address
            if (filter_var($email_to_unblock, FILTER_VALIDATE_EMAIL)) {
                // Update user's status to 'active'
                $stmt = $pdo->prepare("UPDATE users SET status = 'active', blocked_at = NULL WHERE email = ?");
                if ($stmt->execute([$email_to_unblock])) {
                    if ($stmt->rowCount() > 0) {
                        $success_message = "User with email <strong>" . htmlspecialchars($email_to_unblock) . "</strong> has been unblocked.";

                        // Log the action
                        $action = 'Unblocked User';
                        $details = "Admin ID {$_SESSION['admin_id']} unblocked user $email_to_unblock.";
                        $log_stmt = $pdo->prepare("INSERT INTO logs (admin_id, action, details) VALUES (?, ?, ?)");
                        $log_stmt->execute([$_SESSION['admin_id'], $action, $details]);
                    } else {
                        $error_message = "Email address not found.";
                    }
                } else {
                    $error_message = "Failed to unblock user.";
                }
            } else {
                $error_message = "Invalid email address format.";
            }
        }
    }
}

// Fetch all blocked users
$stmt = $pdo->query("SELECT id, email, blocked_at FROM users WHERE status = 'blocked' ORDER BY blocked_at DESC");
$blocked_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SecureMail Admin - Blocked Users</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts and Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <!-- Embedded CSS -->
    <style>
        /* Reset and Basic Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            color: #FFFFFF;
            background-color: #0B0B0B;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .admin-sidebar {
            width: 250px;
            background-color: #121212;
            color: #e8eaed;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            overflow-y: auto;
        }

        .admin-sidebar a {
            padding: 15px 20px;
            text-decoration: none;
            color: #e8eaed;
            font-size: 16px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
        }

        .admin-sidebar a:hover,
        .admin-sidebar a.active {
            background-color: #1E1E1E;
        }

        .admin-sidebar a .material-icons-outlined {
            margin-right: 15px;
            font-size: 24px;
        }

        /* Navbar Styling */
        .admin-navbar {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            height: 60px;
            background-color: #1E1E1E;
            border-bottom: 1px solid #333333;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            z-index: 1000;
        }

        .admin-navbar h1 {
            font-size: 24px;
            color: #00FF7F;
            display: flex;
            align-items: center;
            margin: 0;
        }

        .admin-navbar h1 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .logout-button {
            background-color: #FF4D4D;
            color: #FFFFFF;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
            cursor: pointer;
        }

        .logout-button:hover {
            background-color: #CC0000;
        }

        .logout-button .material-icons-outlined {
            margin-right: 5px;
            font-size: 20px;
        }

        /* Main Content Styling */
        .admin-main-content {
            margin-left: 250px;
            padding: 80px 30px 30px 30px; /* Top padding accounts for navbar */
            flex: 1;
            background-color: #0B0B0B;
            min-height: 100vh;
            color: #FFFFFF;
        }

        /* Message Styles */
        .messages {
            max-width: 800px;
            margin: 0 auto 20px auto;
        }

        .messages .success,
        .messages .error {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .messages .success {
            background-color: #2E7D32;
            color: #FFFFFF;
        }

        .messages .error {
            background-color: #D32F2F;
            color: #FFFFFF;
        }

        /* Block Form Styles */
        .block-form {
            max-width: 800px;
            margin: 0 auto 40px auto;
            background-color: #1E1E1E;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,255,127,0.2);
        }

        .block-form h2 {
            margin-top: 0;
            color: #00FF7F;
            display: flex;
            align-items: center;
        }

        .block-form h2 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .block-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #FFFFFF;
        }

        .block-form input[type="email"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #333333;
            border-radius: 4px;
            background-color: #2C2C2C;
            color: #FFFFFF;
            font-size: 16px;
        }

        .block-form input::placeholder {
            color: #AAAAAA;
        }

        .block-form button {
            background-color: #FF4D4D;
            color: #FFFFFF;
            padding: 14px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
            font-size: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
        }

        .block-form button .material-icons-outlined {
            margin-right: 8px;
            font-size: 24px;
        }

        .block-form button:hover {
            background-color: #CC0000;
        }

        /* Table Styles */
        .blocked-users-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
            color: #FFFFFF;
        }

        .blocked-users-table th,
        .blocked-users-table td {
            border: 1px solid #333333;
            padding: 12px;
            text-align: left;
        }

        .blocked-users-table th {
            background-color: #1E1E1E;
            color: #00FF7F;
            font-weight: 500;
        }

        .blocked-users-table tr:nth-child(even) {
            background-color: #121212;
        }

        .blocked-users-table tr:hover {
            background-color: #1E1E1E;
        }

        /* Unblock Button */
        .unblock-button {
            background-color: #00FF7F;
            color: #121212;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 14px;
            display: flex;
            align-items: center;
        }

        .unblock-button .material-icons-outlined {
            margin-right: 5px;
            font-size: 20px;
        }

        .unblock-button:hover {
            background-color: #00CC66;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .admin-sidebar {
                width: 200px;
            }

            .admin-navbar {
                left: 200px;
            }

            .admin-main-content {
                margin-left: 200px;
            }

            .block-form,
            .messages {
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            .admin-sidebar {
                position: fixed;
                left: -250px;
                transition: left 0.3s;
            }

            .admin-sidebar.active {
                left: 0;
            }

            .admin-navbar {
                left: 0;
            }

            .admin-main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="admin-sidebar">
        <a href="admin_dashboard.php">
            <span class="material-icons-outlined">dashboard</span> Dashboard
        </a>
        <a href="admin_manage_users.php">
            <span class="material-icons-outlined">people</span> Manage Users
        </a>
        <a href="admin_manage_logs.php">
            <span class="material-icons-outlined">description</span> View Logs
        </a>
        <a href="block_users.php" class="active">
            <span class="material-icons-outlined">block</span> Blocked Users
        </a>
        <a href="add_admin.php">
            <span class="material-icons-outlined">person_add</span> Add Admin
        </a>
    </div>

    <!-- Navbar -->
    <div class="admin-navbar">
        <h1>
            <span class="material-icons-outlined">block</span> Blocked Users
        </h1>
        <form action="admin_logout.php" method="POST">
            <button type="submit" class="logout-button">
                <span class="material-icons-outlined">logout</span> Logout
            </button>
        </form>
    </div>

    <!-- Main Content -->
    <div class="admin-main-content">

        <!-- Messages -->
        <div class="messages">
            <?php if (!empty($success_message)): ?>
                <div class="success"><?php echo $success_message; ?></div>
            <?php elseif (!empty($error_message)): ?>
                <div class="error"><?php echo $error_message; ?></div>
            <?php endif; ?>
        </div>

        <!-- Block Form -->
        <div class="block-form">
            <h2>
                <span class="material-icons-outlined">block</span> Block a User by Email
            </h2>
            <form action="block_users.php" method="POST">
                <!-- CSRF Token -->
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">

                <label for="email"><span class="material-icons-outlined">email</span> Email Address:</label>
                <input type="email" id="email" name="email" placeholder="Enter email address to block" required>

                <button type="submit" name="block_user">
                    <span class="material-icons-outlined">block</span> Block User
                </button>
            </form>
        </div>

        <!-- Blocked Users Table -->
        <h2 style="color: #00FF7F; margin-bottom: 20px;">
            <span class="material-icons-outlined">list</span> Currently Blocked Users
        </h2>
        <table class="blocked-users-table">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Email Address</th>
                    <th>Blocked At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($blocked_users): ?>
                    <?php foreach ($blocked_users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['blocked_at']); ?></td>
                            <td>
                                <form action="block_users.php" method="POST" style="display:inline;">
                                    <!-- CSRF Token -->
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                    <input type="hidden" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
                                    <button type="submit" name="unblock_user" class="unblock-button">
                                        <span class="material-icons-outlined">delete</span> Unblock
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">No users are currently blocked.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

</body>
</html>
