<?php
// edit_user.php

// Enable error reporting (Development only)
// Disable in production
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session with secure settings
session_set_cookie_params([
    'lifetime' => 86400, // 1 day
    'path' => '/',
    'domain' => 'sec-email.site', // Replace with your actual domain
    'secure' => true, // Ensure HTTPS is used
    'httponly' => true, // Prevents JavaScript access
    'samesite' => 'Strict', // Prevents CSRF
]);
session_start();

// Admin authentication check
if (
    !isset($_SESSION['admin_id']) ||
    !isset($_SESSION['is_admin']) ||
    $_SESSION['is_admin'] !== true
) {
    header("Location: admin_login.php");
    exit();
}

// Include the database configuration file
require_once '../config.php'; // Adjust the path as necessary

// Initialize variables
$error_message = '';
$success_message = '';
$user = null;

// CSRF Protection: Generate CSRF token if not present
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if 'id' parameter is present
if (!isset($_GET['id']) && !isset($_POST['id'])) {
    $error_message = "No user ID specified.";
} else {
    // Determine if this is a GET or POST request
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Handle form submission to update user
        // CSRF token validation
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            $error_message = "Invalid CSRF token.";
            // Optionally log this event
            error_log("CSRF token mismatch on edit_user.php from IP: " . $_SERVER['REMOTE_ADDR']);
        } else {
            $user_id = intval($_POST['id']);
            $email = isset($_POST['email']) ? trim($_POST['email']) : '';
            $role = isset($_POST['role']) ? trim($_POST['role']) : 'user';
            $status = isset($_POST['status']) ? trim($_POST['status']) : 'pending';

            // Validate inputs
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error_message = "Please enter a valid email address.";
            } elseif (empty($email)) {
                $error_message = "Email cannot be empty.";
            } elseif (!in_array($role, ['user', 'admin'])) {
                $error_message = "Invalid role selected.";
            } elseif (!in_array($status, ['pending', 'active', 'blocked'])) {
                $error_message = "Invalid status selected.";
            } else {
                try {
                    // Check if the email is already taken by another user
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                    $stmt->execute([$email, $user_id]);
                    if ($stmt->fetch()) {
                        $error_message = "Email is already taken by another user.";
                    } else {
                        // Update user details
                        $stmt = $pdo->prepare("UPDATE users SET email = ?, role = ?, status = ? WHERE id = ?");
                        if ($stmt->execute([$email, $role, $status, $user_id])) {
                            $success_message = "User updated successfully.";
                            // Optionally log this action
                            error_log("Admin ID " . $_SESSION['admin_id'] . " edited User ID " . $user_id);
                        } else {
                            $error_message = "Failed to update user.";
                        }
                    }
                } catch (PDOException $e) {
                    error_log("Error editing user: " . $e->getMessage());
                    $error_message = "An unexpected error occurred while editing the user.";
                }
            }

            // Fetch the updated user data
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch();
                if (!$user) {
                    $error_message = "User not found.";
                }
            } catch (PDOException $e) {
                error_log("Error fetching user: " . $e->getMessage());
                $error_message = "An unexpected error occurred while fetching the user.";
            }
        }
    } else {
        // Handle initial GET request to display user data
        $user_id = intval($_GET['id']);
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();
            if (!$user) {
                $error_message = "User not found.";
            }
        } catch (PDOException $e) {
            error_log("Error fetching user: " . $e->getMessage());
            $error_message = "An unexpected error occurred while fetching the user.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User - SecureMail Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts and Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <!-- Embedded CSS -->
    <style>
        /* Basic Styles */

        body {
            font-family: 'Roboto', sans-serif;
            color: #FFFFFF;
            background-color: #0B0B0B;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .admin-sidebar {
            width: 250px;
            background-color: #121212;
            color: #e8eaed;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            overflow-y: auto;
        }

        .admin-sidebar a {
            padding: 15px 20px;
            text-decoration: none;
            color: #e8eaed;
            font-size: 16px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
        }

        .admin-sidebar a:hover,
        .admin-sidebar a.active {
            background-color: #1E1E1E;
        }

        .admin-sidebar a .material-icons-outlined {
            margin-right: 15px;
            font-size: 24px;
        }

        /* Navbar Styling */
        .admin-navbar {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            height: 60px;
            background-color: #1E1E1E;
            border-bottom: 1px solid #333333;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            z-index: 1000;
        }

        .admin-navbar h1 {
            font-size: 24px;
            color: #00FF7F;
            display: flex;
            align-items: center;
            margin: 0;
        }

        .admin-navbar h1 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .logout-button {
            background-color: #FF4D4D;
            color: #FFFFFF;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
            cursor: pointer;
        }

        .logout-button:hover {
            background-color: #CC0000;
        }

        .logout-button .material-icons-outlined {
            margin-right: 5px;
            font-size: 20px;
        }

        /* Main Content Styling */
        .admin-main-content {
            margin-left: 250px;
            padding: 80px 30px 30px 30px; /* Top padding accounts for navbar */
            flex: 1;
            background-color: #0B0B0B;
            min-height: 100vh;
            color: #FFFFFF;
        }

        /* Message Styles */
        .message {
            max-width: 800px;
            margin: 0 auto 20px auto;
            padding: 15px;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
        }

        .success-message {
            background-color: #2E7D32;
            color: #FFFFFF;
        }

        .error-message {
            background-color: #D32F2F;
            color: #FFFFFF;
        }

        /* Edit User Container */
        .edit-user-container {
            max-width: 600px;
            margin: 40px auto;
            padding: 25px;
            background-color: #1E1E1E;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,255,127,0.2);
        }

        .edit-user-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #00FF7F;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .edit-user-container h2 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .edit-user-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #FFFFFF;
        }

        .edit-user-form input,
        .edit-user-form select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #333333;
            border-radius: 4px;
            background-color: #2C2C2C;
            color: #FFFFFF;
            font-size: 16px;
        }

        .edit-user-form input::placeholder {
            color: #AAAAAA;
        }

        .edit-user-form button {
            width: 100%;
            padding: 14px;
            background-color: #00FF7F;
            color: #121212;
            border: none;
            border-radius: 4px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .edit-user-form button .material-icons-outlined {
            margin-right: 8px;
            font-size: 24px;
        }

        .edit-user-form button:hover {
            background-color: #00CC66;
        }

    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="admin-sidebar">
        <a href="admin_dashboard.php">
            <span class="material-icons-outlined">dashboard</span> Dashboard
        </a>
        <a href="admin_manage_users.php" class="active">
            <span class="material-icons-outlined">people</span> Manage Users
        </a>
        <a href="admin_manage_logs.php">
            <span class="material-icons-outlined">description</span> View Logs
        </a>
        <a href="block_ips.php">
            <span class="material-icons-outlined">block</span> Blocked IPs
        </a>
        <a href="add_admin.php">
            <span class="material-icons-outlined">person_add</span> Add Admin
        </a>
    </div>

    <!-- Navbar -->
    <div class="admin-navbar">
        <h1>
            <span class="material-icons-outlined">people</span> Manage Users
        </h1>
        <form action="admin_logout.php" method="POST">
            <button type="submit" class="logout-button">
                <span class="material-icons-outlined">logout</span> Logout
            </button>
        </form>
    </div>

    <!-- Main Content -->
    <div class="admin-main-content">

        <div class="edit-user-container">
            <h2>
                <span class="material-icons-outlined">edit</span> Edit User
            </h2>

            <!-- Display Success or Error Messages -->
            <?php if (!empty($success_message)): ?>
                <div class="message success-message"><?php echo htmlspecialchars($success_message); ?></div>
            <?php endif; ?>
            <?php if (!empty($error_message)): ?>
                <div class="message error-message"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <?php if ($user): ?>
                <form action="edit_user.php" method="POST" class="edit-user-form">
                    <!-- CSRF Token -->
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <!-- User ID -->
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">

                    <label for="email"><span class="material-icons-outlined">email</span> Email:</label>
                    <input type="email" id="email" name="email" placeholder="Enter user email" required value="<?php echo htmlspecialchars($user['email']); ?>">

                    <label for="role"><span class="material-icons-outlined">verified_user</span> Role:</label>
                    <select id="role" name="role" required>
                        <option value="user" <?php echo ($user['role'] === 'user') ? 'selected' : ''; ?>>User</option>
                        <option value="admin" <?php echo ($user['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                    </select>

                    <label for="status"><span class="material-icons-outlined">assignment</span> Status:</label>
                    <select id="status" name="status" required>
                        <option value="pending" <?php echo ($user['status'] === 'pending') ? 'selected' : ''; ?>>Pending</option>
                        <option value="active" <?php echo ($user['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
                        <option value="blocked" <?php echo ($user['status'] === 'blocked') ? 'selected' : ''; ?>>Blocked</option>
                    </select>

                    <button type="submit" name="edit_user">
                        <span class="material-icons-outlined">save</span> Save Changes
                    </button>
                </form>
            <?php else: ?>
                <p>User not found.</p>
            <?php endif; ?>

        </div>

    </div>

</body>
</html>
