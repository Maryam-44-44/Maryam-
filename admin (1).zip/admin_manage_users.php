<?php
// admin_manage_users.php

// Enable error reporting (Development only)
// Disable in production
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Define a base path for including files
define('BASE_PATH', __DIR__ . '/../');

// Start session with secure settings
session_set_cookie_params([
    'lifetime' => 86400, // 1 day
    'path' => '/',
    'domain' => 'sec-email.site', // Replace with your actual domain
    'secure' => true, // Ensure HTTPS is used
    'httponly' => true, // Prevents JavaScript access
    'samesite' => 'Strict', // Prevents CSRF
]);
session_start();

// Admin authentication check
if (
    !isset($_SESSION['admin_id']) ||
    !isset($_SESSION['is_admin']) ||
    $_SESSION['is_admin'] !== true
) {
    header("Location: admin_login.php");
    exit();
}

// Include the database configuration file
require_once BASE_PATH . 'config.php'; // Adjust the path as necessary

// Initialize variables for messages
$success_message = '';
$error_message = '';

// Initialize $active_users and $pending_users as empty arrays to prevent undefined variable errors
$active_users = [];
$pending_users = [];

// CSRF Protection: Generate CSRF token if not present
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_message = "Invalid CSRF token.";
        // Optionally log this event
        error_log("CSRF token mismatch on admin_manage_users.php from IP: " . $_SERVER['REMOTE_ADDR']);
    } else {
        // Determine the action based on the submitted button
        if (isset($_POST['delete_user'])) {
            // Handle deleting a user
            $user_id = intval($_POST['user_id']);
            // Prevent admin from deleting themselves
            if ($user_id === $_SESSION['admin_id']) {
                $error_message = "You cannot delete your own account.";
            } else {
                try {
                    // Delete the user from the database
                    $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
                    if ($stmt->execute(['id' => $user_id])) {
                        $success_message = "User deleted successfully.";
                        // Optionally log this action
                        error_log("Admin ID " . $_SESSION['admin_id'] . " deleted User ID " . $user_id);
                    } else {
                        $error_message = "Failed to delete user.";
                    }
                } catch (PDOException $e) {
                    error_log("Error deleting user: " . $e->getMessage());
                    $error_message = "An unexpected error occurred while deleting the user.";
                }
            }
        } elseif (isset($_POST['approve_user'])) {
            // Handle approving a pending user
            $user_id = intval($_POST['user_id']);
            try {
                $stmt = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = :id");
                if ($stmt->execute(['id' => $user_id])) {
                    $success_message = "User approved successfully.";
                    // Optionally log this action
                    error_log("Admin ID " . $_SESSION['admin_id'] . " approved User ID " . $user_id);
                } else {
                    $error_message = "Failed to approve user.";
                }
            } catch (PDOException $e) {
                error_log("Error approving user: " . $e->getMessage());
                $error_message = "An unexpected error occurred while approving the user.";
            }
        } elseif (isset($_POST['reject_user'])) {
            // Handle rejecting a pending user
            $user_id = intval($_POST['user_id']);
            try {
                $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
                if ($stmt->execute(['id' => $user_id])) {
                    $success_message = "User rejected and deleted successfully.";
                    // Optionally log this action
                    error_log("Admin ID " . $_SESSION['admin_id'] . " rejected and deleted User ID " . $user_id);
                } else {
                    $error_message = "Failed to reject user.";
                }
            } catch (PDOException $e) {
                error_log("Error rejecting user: " . $e->getMessage());
                $error_message = "An unexpected error occurred while rejecting the user.";
            }
        } elseif (isset($_POST['add_user'])) {
            // Handle adding a new user
            $email = isset($_POST['email']) ? trim($_POST['email']) : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            $role = isset($_POST['role']) ? trim($_POST['role']) : 'user'; // Default role 'user'

            // Validate inputs
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error_message = "Please enter a valid email address.";
            } elseif (empty($password)) {
                $error_message = "Please enter a password.";
            } elseif (strlen($password) < 8) {
                $error_message = "Password must be at least 8 characters long.";
            } elseif (!in_array($role, ['user', 'admin'])) {
                $error_message = "Invalid role selected.";
            } else {
                try {
                    // Check if the email already exists
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
                    $stmt->execute(['email' => $email]);
                    if ($stmt->fetch()) {
                        $error_message = "Email is already registered.";
                    } else {
                        // Hash the password
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        // Insert the new user with status 'pending'
                        $stmt = $pdo->prepare("INSERT INTO users (email, password, role, status, created_at) VALUES (:email, :password, :role, 'pending', NOW())");
                        if ($stmt->execute([
                            'email' => $email,
                            'password' => $hashed_password,
                            'role' => $role
                        ])) {
                            $success_message = "New user added successfully and is pending approval.";
                            // Optionally log this action
                            error_log("Admin ID " . $_SESSION['admin_id'] . " added new User with Email: " . $email);
                        } else {
                            $error_message = "Failed to add new user.";
                        }
                    }
                } catch (PDOException $e) {
                    error_log("Error adding user: " . $e->getMessage());
                    $error_message = "An unexpected error occurred while adding the user.";
                }
            }
        }
    }
} // Closing brace for POST handling

// Fetch active users from the database
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE status = 'active' ORDER BY id ASC");
    $stmt->execute();
    $active_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching active users: " . $e->getMessage());
    $error_message = "An unexpected error occurred while fetching active users.";
}

// Fetch pending users from the database
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE status = 'pending' ORDER BY id ASC");
    $stmt->execute();
    $pending_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching pending users: " . $e->getMessage());
    $error_message = "An unexpected error occurred while fetching pending users.";
}

// Ensure $active_users and $pending_users are arrays
if (!is_array($active_users)) {
    $active_users = [];
}
if (!is_array($pending_users)) {
    $pending_users = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SecureMail Admin - Manage Users</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts and Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <!-- Embedded CSS -->
    <style>
        /* Basic Styles */

        body {
            font-family: 'Roboto', sans-serif;
            color: #FFFFFF;
            background-color: #0B0B0B;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .admin-sidebar {
            width: 250px;
            background-color: #121212;
            color: #e8eaed;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            overflow-y: auto;
        }

        .admin-sidebar a {
            padding: 15px 20px;
            text-decoration: none;
            color: #e8eaed;
            font-size: 16px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
        }

        .admin-sidebar a:hover,
        .admin-sidebar a.active {
            background-color: #1E1E1E;
        }

        .admin-sidebar a .material-icons-outlined {
            margin-right: 15px;
            font-size: 24px;
        }

        /* Navbar Styling */
        .admin-navbar {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            height: 60px;
            background-color: #1E1E1E;
            border-bottom: 1px solid #333333;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            z-index: 1000;
        }

        .admin-navbar h1 {
            font-size: 24px;
            color: #00FF7F;
            display: flex;
            align-items: center;
            margin: 0;
        }

        .admin-navbar h1 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .logout-button {
            background-color: #FF4D4D;
            color: #FFFFFF;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
            cursor: pointer;
        }

        .logout-button:hover {
            background-color: #CC0000;
        }

        .logout-button .material-icons-outlined {
            margin-right: 5px;
            font-size: 20px;
        }

        /* Main Content Styling */
        .admin-main-content {
            margin-left: 250px;
            padding: 80px 30px 30px 30px; /* Top padding accounts for navbar */
            flex: 1;
            background-color: #0B0B0B;
            min-height: 100vh;
            color: #FFFFFF;
        }

        /* Message Styles */
        .message {
            max-width: 800px;
            margin: 0 auto 20px auto;
            padding: 15px;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
        }

        .success-message {
            background-color: #2E7D32;
            color: #FFFFFF;
        }

        .error-message {
            background-color: #D32F2F;
            color: #FFFFFF;
        }

        /* Users Table Styles */
        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
            color: #FFFFFF;
        }

        .user-table th,
        .user-table td {
            border: 1px solid #333333;
            padding: 12px;
            text-align: left;
        }

        .user-table th {
            background-color: #1E1E1E;
            color: #00FF7F;
            font-weight: 500;
        }

        .user-table tr:nth-child(even) {
            background-color: #121212;
        }

        .user-table tr:hover {
            background-color: #1E1E1E;
        }

        /* Action Buttons */
        .action-buttons a,
        .action-buttons button {
            padding: 6px 10px;
            margin-right: 5px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
            color: inherit;
        }

        .action-buttons a.edit-button {
            background-color: #00B0FF;
            color: #121212;
        }

        .action-buttons a.edit-button:hover {
            background-color: #0081CB;
        }

        .action-buttons button.delete-button {
            background-color: #FF4D4D;
            color: #FFFFFF;
        }

        .action-buttons button.delete-button:hover {
            background-color: #CC0000;
        }

        /* Add User Form Styles */
        .add-user-container {
            max-width: 600px;
            margin: 40px auto;
            padding: 25px;
            background-color: #1E1E1E;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,255,127,0.2);
        }

        .add-user-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #00FF7F;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .add-user-container h2 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .add-user-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #FFFFFF;
        }

        .add-user-form input,
        .add-user-form select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #333333;
            border-radius: 4px;
            background-color: #2C2C2C;
            color: #FFFFFF;
            font-size: 16px;
        }

        .add-user-form input::placeholder {
            color: #AAAAAA;
        }

        .add-user-form button {
            width: 100%;
            padding: 14px;
            background-color: #00FF7F;
            color: #121212;
            border: none;
            border-radius: 4px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .add-user-form button .material-icons-outlined {
            margin-right: 8px;
            font-size: 24px;
        }

        .add-user-form button:hover {
            background-color: #00CC66;
        }

        /* Pending Users Section */
        .pending-users-container {
            margin-bottom: 40px;
        }

        .pending-users-container h2 {
            margin-bottom: 20px;
            color: #FFD700;
            display: flex;
            align-items: center;
        }

        .pending-users-container h2 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .action-buttons form {
            display: inline;
        }

        .action-buttons button.approve-button {
            background-color: #2E7D32;
            color: #FFFFFF;
            margin-right: 5px;
        }

        .action-buttons button.approve-button:hover {
            background-color: #1B5E20;
        }

        .action-buttons button.reject-button {
            background-color: #D32F2F;
            color: #FFFFFF;
        }

        .action-buttons button.reject-button:hover {
            background-color: #B71C1C;
        }

        /* Active Users Section Title */
        .section-title {
            margin-bottom: 20px;
            color: #00FF7F;
            display: flex;
            align-items: center;
        }

        .section-title .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="admin-sidebar">
        <a href="admin_dashboard.php" class="active">
            <span class="material-icons-outlined">dashboard</span> Dashboard
        </a>
        <a href="admin_manage_users.php">
            <span class="material-icons-outlined">people</span> Manage Users
        </a>
        <a href="admin_manage_logs.php">
            <span class="material-icons-outlined">description</span> View Logs
        </a>
        <a href="block_users.php">
            <span class="material-icons-outlined">block</span> Blocked Users
        </a>
        <a href="add_admin.php">
            <span class="material-icons-outlined">person_add</span> Add Admin
        </a>
    </div>

    <!-- Navbar -->
    <div class="admin-navbar">
        <h1>
            <span class="material-icons-outlined">people</span> Manage Users
        </h1>
        <form action="admin_logout.php" method="POST">
            <button type="submit" class="logout-button">
                <span class="material-icons-outlined">logout</span> Logout
            </button>
        </form>
    </div>

    <!-- Main Content -->
    <div class="admin-main-content">

        <!-- Display Success or Error Messages -->
        <?php if (!empty($success_message)): ?>
            <div class="message success-message"><?php echo htmlspecialchars($success_message, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
        <?php if (!empty($error_message)): ?>
            <div class="message error-message"><?php echo htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <!-- Add New User Section -->
        <div class="add-user-container">
            <h2>
                <span class="material-icons-outlined">person_add</span> Add New User
            </h2>
            <form action="admin_manage_users.php" method="POST" class="add-user-form">
                <!-- CSRF Token -->
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

                <label for="email"><span class="material-icons-outlined">email</span> Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter user email" required>

                <label for="password"><span class="material-icons-outlined">lock</span> Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter user password" required>

                <label for="role"><span class="material-icons-outlined">verified_user</span> Role:</label>
                <select id="role" name="role" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>

                <button type="submit" name="add_user">
                    <span class="material-icons-outlined">add</span> Add User
                </button>
            </form>
        </div>

        <!-- Pending Users Section -->
        <div class="pending-users-container">
            <h2>
                <span class="material-icons-outlined">hourglass_empty</span> Pending Users
            </h2>
            <?php if (count($pending_users) > 0): ?>
                <table class="user-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Registered At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pending_users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($user['role'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($user['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td class="action-buttons">
                                    <!-- Approve Button -->
                                    <form method="POST" action="admin_manage_users.php" style="display:inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <button type="submit" name="approve_user" class="approve-button">
                                            <span class="material-icons-outlined">check_circle</span> Approve
                                        </button>
                                    </form>

                                    <!-- Reject Button -->
                                    <form method="POST" action="admin_manage_users.php" style="display:inline;" onsubmit="return confirm('Are you sure you want to reject and delete this user?');">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <button type="submit" name="reject_user" class="reject-button">
                                            <span class="material-icons-outlined">cancel</span> Reject
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No pending users at this time.</p>
            <?php endif; ?>
        </div>

        <!-- Active Users Section -->
        <h2 class="section-title">
            <span class="material-icons-outlined">people_alt</span> Active Users
        </h2>
        <?php if (count($active_users) > 0): ?>
            <table class="user-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Registered At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($active_users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($user['role'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($user['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="action-buttons">
                                <!-- Edit Button -->
                                <a href="edit_user.php?id=<?php echo urlencode($user['id']); ?>" class="edit-button">
                                    <span class="material-icons-outlined">edit</span> Edit
                                </a>

                                <!-- Delete Button -->
                                <form method="POST" action="admin_manage_users.php" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
                                    <button type="submit" name="delete_user" class="delete-button">
                                        <span class="material-icons-outlined">delete</span> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No active users found.</p>
        <?php endif; ?>

    </div>

</body>
</html>
