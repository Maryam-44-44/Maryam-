<?php
// add_admin.php

// Enable error reporting (Development only)
// Remove or comment out these lines in production
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session with secure settings
session_set_cookie_params([
    'lifetime' => 86400, // 1 day
    'path' => '/',
    'domain' => 'yourdomain.com', // Replace with your actual domain
    'secure' => true, // Ensure HTTPS is used
    'httponly' => true, // Prevents JavaScript access
    'samesite' => 'Strict', // Prevents CSRF
]);
session_start();

// Admin authentication check
if (
    !isset($_SESSION['admin_id']) ||
    !isset($_SESSION['is_admin']) ||
    $_SESSION['is_admin'] !== true
) {
    header("Location: admin_login.php");
    exit();
}

// Include the database configuration file
require_once '../config.php'; // Use require_once to prevent multiple inclusions

// Initialize variables for messages
$success_message = '';
$error_message = '';

// CSRF Protection: Generate CSRF token if not present
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_message = "Invalid CSRF token.";
    } else {
        // Retrieve and sanitize input data
        $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
        $password = trim($_POST['password']);

        if (!$email) {
            $error_message = "Please enter a valid email address.";
        } elseif (empty($password)) {
            $error_message = "Please enter a password.";
        } elseif (strlen($password) < 8) {
            $error_message = "Password must be at least 8 characters long.";
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $error_message = "Password must contain at least one uppercase letter.";
        } elseif (!preg_match('/[a-z]/', $password)) {
            $error_message = "Password must contain at least one lowercase letter.";
        } elseif (!preg_match('/[0-9]/', $password)) {
            $error_message = "Password must contain at least one number.";
        } else {
            // Hash the password for security
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $role = 'admin'; // Setting role as 'admin'

            try {
                // Check if the email already exists using a prepared statement
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->rowCount() > 0) {
                    $error_message = "Error: This email is already registered.";
                } else {
                    // Insert new admin into the database using a prepared statement
                    $stmt = $pdo->prepare("INSERT INTO users (email, password, role) VALUES (?, ?, ?)");
                    if ($stmt->execute([$email, $hashed_password, $role])) {
                        $success_message = "Admin added successfully!";
                        // Optionally, log the successful addition
                        error_log("New admin added: " . $email . " by admin ID: " . $_SESSION['admin_id']);
                    } else {
                        $error_message = "Error adding admin. Please try again.";
                    }
                }
            } catch (PDOException $e) {
                // Log the error to a file
                error_log("Error adding admin: " . $e->getMessage());
                // Display a generic error message to the user
                $error_message = "An unexpected error occurred. Please try again later.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SecureMail Admin - Add New Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts and Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <!-- Embedded CSS -->
    <style>
        /* Reset and Basic Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            color: #FFFFFF;
            background-color: #0B0B0B;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .admin-sidebar {
            width: 250px;
            background-color: #121212;
            color: #e8eaed;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            overflow-y: auto;
        }

        .admin-sidebar a {
            padding: 15px 20px;
            text-decoration: none;
            color: #e8eaed;
            font-size: 16px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
        }

        .admin-sidebar a:hover,
        .admin-sidebar a.active {
            background-color: #1E1E1E;
        }

        .admin-sidebar a .material-icons-outlined {
            margin-right: 15px;
            font-size: 24px;
        }

        /* Navbar Styling */
        .admin-navbar {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            height: 60px;
            background-color: #1E1E1E;
            border-bottom: 1px solid #333333;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            z-index: 1000;
        }

        .admin-navbar h1 {
            font-size: 24px;
            color: #00FF7F;
            display: flex;
            align-items: center;
            margin: 0;
        }

        .admin-navbar h1 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .logout-button {
            background-color: #FF4D4D;
            color: #FFFFFF;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
            cursor: pointer;
        }

        .logout-button:hover {
            background-color: #CC0000;
        }

        .logout-button .material-icons-outlined {
            margin-right: 5px;
            font-size: 20px;
        }

        /* Main Content Styling */
        .admin-main-content {
            margin-left: 250px;
            padding: 80px 30px 30px 30px; /* Top padding accounts for navbar */
            flex: 1;
            background-color: #0B0B0B;
            min-height: 100vh;
            color: #FFFFFF;
        }

        /* Message Styles */
        .message {
            max-width: 800px;
            margin: 0 auto 20px auto;
            padding: 15px;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
        }

        .success-message {
            background-color: #2E7D32;
            color: #FFFFFF;
        }

        .error-message {
            background-color: #D32F2F;
            color: #FFFFFF;
        }

        /* Add Admin Form Styles */
        .add-admin-form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #1E1E1E;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,255,127,0.2);
        }

        .add-admin-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #FFFFFF;
        }

        .add-admin-form input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #333333;
            border-radius: 4px;
            background-color: #2C2C2C;
            color: #FFFFFF;
            font-size: 16px;
        }

        .add-admin-form input::placeholder {
            color: #AAAAAA;
        }

        .add-admin-form button {
            width: 100%;
            padding: 14px;
            background-color: #00FF7F;
            color: #121212;
            border: none;
            border-radius: 4px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .add-admin-form button .material-icons-outlined {
            margin-right: 8px;
            font-size: 24px;
        }

        .add-admin-form button:hover {
            background-color: #00CC66;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .admin-sidebar {
                width: 200px;
            }

            .admin-navbar {
                left: 200px;
            }

            .admin-main-content {
                margin-left: 200px;
            }

            .add-admin-form,
            .message {
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            .admin-sidebar {
                position: fixed;
                left: -250px;
                transition: left 0.3s;
            }

            .admin-sidebar.active {
                left: 0;
            }

            .admin-navbar {
                left: 0;
            }

            .admin-main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>

   <div class="admin-sidebar">
        <a href="admin_dashboard.php" class="active">
            <span class="material-icons-outlined">dashboard</span> Dashboard
        </a>
        <a href="admin_manage_users.php">
            <span class="material-icons-outlined">people</span> Manage Users
        </a>
        <a href="admin_manage_logs.php">
            <span class="material-icons-outlined">description</span> View Logs
        </a>
        <a href="block_users.php">
            <span class="material-icons-outlined">block</span> Blocked Users
        </a>
        <a href="add_admin.php">
            <span class="material-icons-outlined">person_add</span> Add Admin
        </a>
    </div>

    <!-- Navbar -->
    <div class="admin-navbar">
        <h1>
            <span class="material-icons-outlined">person_add</span> Add New Admin
        </h1>
        <form action="admin_logout.php" method="POST">
            <button type="submit" class="logout-button">
                <span class="material-icons-outlined">logout</span> Logout
            </button>
        </form>
    </div>

    <!-- Main Content -->
    <div class="admin-main-content">

        <!-- Display Success or Error Messages -->
        <?php if (!empty($success_message)): ?>
            <div class="message success-message"><?php echo htmlspecialchars($success_message); ?></div>
        <?php elseif (!empty($error_message)): ?>
            <div class="message error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <!-- Add Admin Form -->
        <form action="add_admin.php" method="POST" class="add-admin-form">
            <!-- CSRF Token -->
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">

            <label for="email">
                <span class="material-icons-outlined">email</span> Email:
            </label>
            <input type="email" id="email" name="email" placeholder="Enter admin email" required>

            <label for="password">
                <span class="material-icons-outlined">vpn_key</span> Password:
            </label>
            <input type="password" id="password" name="password" placeholder="Enter admin password" required>

            <button type="submit">
                <span class="material-icons-outlined">person_add</span> Add Admin
            </button>
        </form>

    </div>

</body>
</html>
