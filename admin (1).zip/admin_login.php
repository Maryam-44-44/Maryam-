<?php
// admin_login.php

// Enable error reporting (Development only)
// Remove or comment out these lines in production
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the database configuration file
require_once '../config.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Generate CSRF token if not set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Function to get the user's IP address
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }
    else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Initialize variables for messages and input values
$error_message = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email_input = isset($_POST['email']) ? trim($_POST['email']) : '';
    $email = filter_var($email_input, FILTER_VALIDATE_EMAIL);
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $ip_address = getUserIP();

    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error_message = "Invalid request.";
    } elseif (!$email || empty($password)) {
        $error_message = "Please fill in all fields.";
    } else {
        try {
            // Check if the user exists and is an admin
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                // Successful login
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['is_admin'] = true;
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];

                // Log the successful login attempt
                $action = 'Admin Login Success';
                $details = "Email: {$user['email']}, IP: {$ip_address}";
                $log_stmt = $pdo->prepare("INSERT INTO logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
                $log_stmt->execute([$user['id'], $action, $details, $ip_address]);

                header("Location: admin_dashboard.php");
                exit();
            } else {
                // Failed login attempt
                $error_message = "Invalid email or password.";

                // Log the failed login attempt
                $action = 'Admin Login Failed';
                $details = "Email: {$email}, IP: {$ip_address}";
                $log_stmt = $pdo->prepare("INSERT INTO logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
                $log_stmt->execute([null, $action, $details, $ip_address]);
            }
        } catch (PDOException $e) {
            error_log("Error during admin login: " . $e->getMessage());
            $error_message = "An unexpected error occurred. Please try again later.";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SecureMail Admin - Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts and Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <!-- Embedded CSS -->
    <style>
        /* Reset some default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            color: #FFFFFF;
            background-color: #0B0B0B;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .header {
            width: 100%;
            background-color: #1E1E1E;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
        }

        .header .logo {
            display: flex;
            align-items: center;
            color: #00FF7F;
            font-size: 24px;
            font-weight: 700;
            text-decoration: none;
        }

        .header .logo .material-icons-outlined {
            font-size: 36px;
            margin-right: 10px;
        }

        .auth-container {
            width: 100%;
            max-width: 400px;
            padding: 40px 30px;
            background-color: #121212;
            border-radius: 8px;
            margin-top: 50px;
            box-shadow: 0 4px 12px rgba(0, 255, 127, 0.2);
        }

        .auth-container h1 {
            font-size: 24px;
            color: #FFFFFF;
            text-align: center;
            margin-bottom: 30px;
            font-weight: 500;
        }

        .auth-container h1 .material-icons-outlined {
            font-size: 30px;
            vertical-align: middle;
            color: #00FF7F;
            margin-right: 8px;
        }

        .error-message {
            background-color: #D32F2F;
            color: #FFFFFF;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
        }

        .auth-form .form-group {
            position: relative;
            margin-bottom: 25px;
        }

        .auth-form .form-group label {
            position: absolute;
            top: 50%;
            left: 12px;
            transform: translateY(-50%);
            color: #AAAAAA;
            font-size: 20px;
        }

        .auth-form .form-group .material-icons-outlined {
            font-size: 24px;
        }

        .auth-form .form-group input {
            width: 100%;
            padding: 14px 12px 14px 48px;
            border: 1px solid #333333;
            border-radius: 5px;
            background-color: #1E1E1E;
            color: #FFFFFF;
            font-size: 16px;
            transition: border-color 0.3s, background-color 0.3s;
        }

        .auth-form .form-group input::placeholder {
            color: #AAAAAA;
        }

        .auth-form .form-group input:focus {
            border-color: #00FF7F;
            outline: none;
            background-color: #2C2C2C;
        }

        .btn-primary {
            width: 100%;
            padding: 14px;
            background-color: #00FF7F;
            border: none;
            border-radius: 5px;
            color: #121212;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-primary .material-icons-outlined {
            font-size: 24px;
            margin-right: 8px;
        }

        .btn-primary:hover {
            background-color: #00CC66;
        }

        .auth-container p {
            text-align: center;
            margin-top: 25px;
            color: #CCCCCC;
            font-size: 14px;
        }

        .auth-container p a {
            color: #00FF7F;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .auth-container p a:hover {
            color: #00CC66;
        }

        /* Footer */
        .footer {
            margin-top: auto;
            padding: 20px 0;
            width: 100%;
            background-color: #1E1E1E;
            text-align: center;
            color: #666666;
            font-size: 14px;
        }

        .footer a {
            color: #00FF7F;
            text-decoration: none;
            margin: 0 10px;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Responsive Design */
        @media (max-width: 480px) {
            .auth-container {
                padding: 30px 20px;
                margin-top: 30px;
            }

            .auth-container h1 {
                font-size: 20px;
            }

            .btn-primary {
                font-size: 16px;
            }

            .auth-container p {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <a href="../index.php" class="logo">
            <span class="material-icons-outlined">admin_panel_settings</span>
            SecureMail Admin
        </a>
    </header>

    <!-- Authentication Container -->
    <div class="auth-container">
        <h1><span class="material-icons-outlined">lock</span>Admin Login</h1>
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        <form action="admin_login.php" method="POST" class="auth-form">
            <!-- CSRF Token -->
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">

            <div class="form-group">
                <label for="email"><span class="material-icons-outlined">email</span></label>
                <input type="email" id="email" name="email" placeholder="Admin Email" required autofocus value="<?php echo htmlspecialchars($email ?? ''); ?>">
            </div>

            <div class="form-group">
                <label for="password"><span class="material-icons-outlined">vpn_key</span></label>
                <input type="password" id="password" name="password" placeholder="Password" required>
            </div>

            <button type="submit" class="btn-primary">
                <span class="material-icons-outlined">login</span>Login
            </button>
        </form>
        <p><a href="#">Forgot password?</a></p>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <a href="#">Privacy</a>
        <a href="#">Terms</a>
        <a href="#">Help</a>
    </footer>
</body>
</html>
