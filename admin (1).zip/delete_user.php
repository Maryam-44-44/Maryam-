<?php
session_start();

// Admin authentication check
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: admin_login.php");
    exit();
}

include '../config.php';  // Database configuration

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Delete user
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);

    header("Location: admin_manage_users.php");
    exit();
} else {
    echo "Invalid User ID.";
    exit();
}
?>
