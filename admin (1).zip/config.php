<?php
$host = 'localhost';
$db = 'u480473927_security';
$user = 'u480473927_security';  // Replace with your database username
$pass = '@Security12312';  // Replace with your database password
$charset = 'utf8mb4';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
