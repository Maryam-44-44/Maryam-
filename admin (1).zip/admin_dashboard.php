<?php
// admin_dashboard.php

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include the database configuration file
require_once '../config.php'; // Adjust the path as needed

// Admin authentication check
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: admin_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SecureMail Admin - Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts and Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <!-- Embedded CSS -->
    <style>
        /* Reset and Basic Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            color: #FFFFFF;
            background-color: #0B0B0B;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .admin-sidebar {
            width: 250px;
            background-color: #121212;
            color: #e8eaed;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            overflow-y: auto;
        }

        .admin-sidebar a {
            padding: 15px 20px;
            text-decoration: none;
            color: #e8eaed;
            font-size: 16px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
        }

        .admin-sidebar a:hover,
        .admin-sidebar a.active {
            background-color: #1E1E1E;
        }

        .admin-sidebar a .material-icons-outlined {
            margin-right: 15px;
            font-size: 24px;
        }

        /* Navbar Styling */
        .admin-navbar {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            height: 60px;
            background-color: #1E1E1E;
            border-bottom: 1px solid #333333;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            z-index: 1000;
        }

        .admin-navbar h1 {
            font-size: 24px;
            color: #00FF7F;
            display: flex;
            align-items: center;
            margin: 0;
        }

        .admin-navbar h1 .material-icons-outlined {
            margin-right: 10px;
            font-size: 32px;
        }

        .logout-button {
            background-color: #FF4D4D;
            color: #FFFFFF;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            transition: background 0.3s;
            cursor: pointer;
        }

        .logout-button:hover {
            background-color: #CC0000;
        }

        .logout-button .material-icons-outlined {
            margin-right: 5px;
            font-size: 20px;
        }

        /* Main Content Styling */
        .admin-main-content {
            margin-left: 250px;
            padding: 80px 30px 30px 30px; /* Top padding accounts for navbar */
            flex: 1;
            background-color: #0B0B0B;
            min-height: 100vh;
        }

        /* Dashboard Cards */
        .dashboard-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .card {
            background-color: #1E1E1E;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,255,127,0.2);
            flex: 1 1 calc(33.333% - 20px);
            min-width: 250px;
            padding: 20px;
            display: flex;
            align-items: center;
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-icon {
            font-size: 40px;
            color: #00FF7F;
            margin-right: 20px;
        }

        .card-icon .material-icons-outlined {
            font-size: 48px;
        }

        .card-info h3 {
            margin: 0 0 10px;
            font-size: 20px;
            color: #FFFFFF;
        }

        .card-info p {
            margin: 0 0 15px;
            color: #CCCCCC;
        }

        .card-link {
            text-decoration: none;
            color: #00FF7F;
            font-weight: 500;
            transition: color 0.3s;
        }

        .card-link:hover {
            color: #00CC66;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .admin-sidebar {
                width: 200px;
            }

            .admin-navbar {
                left: 200px;
            }

            .dashboard-cards {
                flex-direction: column;
            }

            .card {
                flex: 1 1 100%;
            }
        }

        @media (max-width: 576px) {
            .admin-sidebar {
                position: fixed;
                left: -250px;
                transition: left 0.3s;
            }

            .admin-sidebar.active {
                left: 0;
            }

            .admin-navbar {
                left: 0;
            }

            .admin-main-content {
                margin-left: 0;
            }

            .dashboard-cards {
                margin-top: 80px;
            }
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="admin-sidebar">
        <a href="admin_dashboard.php" class="active">
            <span class="material-icons-outlined">dashboard</span> Dashboard
        </a>
        <a href="admin_manage_users.php">
            <span class="material-icons-outlined">people</span> Manage Users
        </a>
        <a href="admin_manage_logs.php">
            <span class="material-icons-outlined">description</span> View Logs
        </a>
        <a href="block_users.php">
            <span class="material-icons-outlined">block</span> Blocked Users
        </a>
        <a href="add_admin.php">
            <span class="material-icons-outlined">person_add</span> Add Admin
        </a>
    </div>

    <!-- Navbar -->
    <div class="admin-navbar">
        <h1>
            <span class="material-icons-outlined">admin_panel_settings</span> Admin Dashboard
        </h1>
        <form action="admin_logout.php" method="POST">
            <button type="submit" class="logout-button">
                <span class="material-icons-outlined">logout</span> Logout
            </button>
        </form>
    </div>

    <!-- Main Content -->
    <div class="admin-main-content">
        <div class="dashboard-cards">
            <div class="card">
                <div class="card-icon">
                    <span class="material-icons-outlined">people</span>
                </div>
                <div class="card-info">
                    <h3>Manage Users</h3>
                    <p>Manage all users in the system</p>
                    <a href="admin_manage_users.php" class="card-link">Go to Users</a>
                </div>
            </div>

            <div class="card">
                <div class="card-icon">
                    <span class="material-icons-outlined">description</span>
                </div>
                <div class="card-info">
                    <h3>View Logs</h3>
                    <p>Review activity and system logs</p>
                    <a href="admin_manage_logs.php" class="card-link">View Logs</a>
                </div>
            </div>

            <div class="card">
                <div class="card-icon">
                    <span class="material-icons-outlined">person_add</span>
                </div>
                <div class="card-info">
                    <h3>Add New Admin</h3>
                    <p>Create new admin accounts</p>
                    <a href="add_admin.php" class="card-link">Add Admin</a>
                </div>
            </div>

            <div class="card">
                <div class="card-icon">
                    <span class="material-icons-outlined">block</span>
                </div>
                <div class="card-info">
                    <h3>Blocked Users</h3>
                    <p>Manage blocked users</p>
                    <a href="block_users.php" class="card-link">Manage Users</a>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
